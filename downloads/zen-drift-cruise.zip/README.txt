ZEN DRIFT CRUISE — DOWNLOAD EDITION

ONLINE PLAY (recommended)
Connect to the internet, then open "Launch Zen Drift Cruise.command" on Mac or "Launch Zen Drift Cruise.bat" on Windows. This opens the current online game, including account sync and public leaderboards.

OFFLINE PLAY
The bundled game remains available in "Launch Zen Drift Cruise Offline.command" or "Launch Zen Drift Cruise Offline.bat". Offline play saves progress on this device. The offline copy requires Node.js 20 or later and installs its dependencies on first launch.

This package includes launchers and the bundled game. It is not a native standalone installer.
