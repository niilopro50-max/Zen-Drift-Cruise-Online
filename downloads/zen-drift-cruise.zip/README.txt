ZEN DRIFT CRUISE — DOWNLOAD EDITION

REQUIREMENT
Install Node.js 20 or later:
https://nodejs.org/

MAC
1. Extract the ZIP.
2. Open "Launch Zen Drift Cruise.command".
3. If macOS blocks it, right-click the file and choose Open.
4. Keep the Terminal window open while playing.

WINDOWS
1. Extract the ZIP.
2. Double-click "Launch Zen Drift Cruise.bat".
3. Keep the launcher window open while playing.

The first launch installs the required game dependencies.
An internet connection is needed for that installation.

The launcher opens the game in your browser.
Press Ctrl+C in the Mac Terminal window, or close the Windows
launcher window, to stop the local game server.

This is the browser-based download edition, not a native
standalone Mac app or Windows executable installer.
