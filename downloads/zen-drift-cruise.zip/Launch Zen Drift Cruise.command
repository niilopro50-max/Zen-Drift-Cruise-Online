#!/bin/zsh
open "https://zen-drift-cruise-online.onrender.com/play?desktop=1"
