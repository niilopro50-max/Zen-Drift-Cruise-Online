#!/bin/zsh
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Please install Node.js 20 or later from https://nodejs.org/"
  read -r "?Press Enter to close..."
  exit 1
fi

if [[ ! -x "$ROOT/node_modules/.bin/tsx" ]]; then
  echo "Installing game dependencies..."
  npm ci
fi

unset PORT
LOG="/tmp/zen-drift-cruise-launch.log"
export ZEN_WEB_ONLY=1

echo "Starting Zen Drift Cruise..."
"$ROOT/node_modules/.bin/tsx" "$ROOT/server.ts" >"$LOG" 2>&1 &
PID=$!

trap 'kill "$PID" 2>/dev/null || true' EXIT INT TERM

FOUND_PORT=""
for i in {1..30}; do
  if [[ -f "$LOG" ]]; then
    FOUND_PORT="$(sed -n 's/.*listening on [^:]*:\([0-9][0-9]*\).*/\1/p' "$LOG" | tail -n 1)"
  fi
  if [[ -n "$FOUND_PORT" ]]; then break; fi
  if ! kill -0 "$PID" 2>/dev/null; then break; fi
  sleep 1
done

if [[ -z "$FOUND_PORT" ]]; then
  echo "The game could not start. Details:"
  cat "$LOG"
  read -r "?Press Enter to close..."
  exit 1
fi

echo "Opening Zen Drift Cruise in your browser..."
open "http://127.0.0.1:$FOUND_PORT/play"
echo "Keep this window open while playing. Press Ctrl+C to stop the game."
wait "$PID"
