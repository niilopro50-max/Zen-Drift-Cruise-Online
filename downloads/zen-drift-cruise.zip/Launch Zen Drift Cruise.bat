@echo off
start "Zen Drift Cruise" "https://zen-drift-cruise-online.onrender.com/play?desktop=1"
