$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root
$env:ZEN_WEB_ONLY = "1"
Remove-Item Env:PORT -ErrorAction SilentlyContinue

$log = Join-Path $env:TEMP "zen-drift-cruise-launch.log"
$err = Join-Path $env:TEMP "zen-drift-cruise-error.log"
Remove-Item $log, $err -ErrorAction SilentlyContinue

$proc = Start-Process -FilePath "cmd.exe" `
  -ArgumentList @("/c", "node_modules\.bin\tsx.cmd server.ts") `
  -WorkingDirectory $root `
  -RedirectStandardOutput $log `
  -RedirectStandardError $err `
  -PassThru

$port = $null
for ($i = 0; $i -lt 30; $i++) {
  Start-Sleep -Seconds 1
  if (Test-Path $log) {
    $content = Get-Content $log -Raw
    $match = [regex]::Match($content, 'listening on .*:(\d+)')
    if ($match.Success) {
      $port = $match.Groups[1].Value
      break
    }
  }
  if ($proc.HasExited) { break }
}

if (-not $port) {
  Write-Host "The game could not start."
  if (Test-Path $log) { Get-Content $log }
  if (Test-Path $err) { Get-Content $err }
  exit 1
}

Write-Host "Opening Zen Drift Cruise in your browser..."
Start-Process "http://127.0.0.1:$port/play"
Write-Host "Keep this window open while playing."
Wait-Process -Id $proc.Id
